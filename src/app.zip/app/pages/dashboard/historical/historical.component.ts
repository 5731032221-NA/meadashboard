import { Router } from '@angular/router';
import {  Component  } from '@angular/core';
import { Label, Color } from 'ng2-charts';


import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

import * as Highcharts from 'highcharts';

// declare var require: any;
// let Boost = require('highcharts/modules/boost');
// let noData = require('highcharts/modules/no-data-to-display');
// let More = require('highcharts/highcharts-more');

// Boost(Highcharts);
// noData(Highcharts);
// More(Highcharts);
// noData(Highcharts);



@Component({
  selector: 'ngx-historical',
  templateUrl: './historical.component.html',
  styleUrls: ['./historical.component.scss'],
})
export class HistoricalComponent  {
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options = {
    rangeSelector: {
      selected: 4
  },

  yAxis: {
      labels: {
          formatter: function () {
              return (this.value > 0 ? ' + ' : '') + this.value + '%';
          }
      },
      plotLines: [{
          value: 0,
          width: 2,
          color: 'silver'
      }]
  },

  plotOptions: {
      series: {
          compare: 'percent',
          showInNavigator: true
      }
  },

  tooltip: {
      pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.change}%)<br/>',
      valueDecimals: 2,
      split: true
  },
  //   series: [{
  //     name: 'Installation',
  //     data: [43934, 52503, 57177, 69658, 97031, 119931, 137133, 154175]
  // }, {
  //     name: 'Manufacturing',
  //     data: [24916, 24064, 29742, 29851, 32490, 30282, 38121, 40434]
  // }, {
  //     name: 'Sales & Distribution',
  //     data: [11744, 17722, 16005, 19771, 20185, 24377, 32147, 39387]
  // }, {
  //     name: 'Project Development',
  //     data: [null, null, 7988, 12169, 15112, 22452, 34400, 34227]
  // }, {
  //     name: 'Other',
  //     data: [12908, 5948, 8105, 11248, 8989, 11816, 18274, 18111]
  // }]
  };
  constructor(private http: HttpClient, private router: Router) {


    // this.http.get<any>('http://20.188.110.129:3000/countmeaprofile').subscribe((res) => { console.log(res) })
   


  }
  


}
